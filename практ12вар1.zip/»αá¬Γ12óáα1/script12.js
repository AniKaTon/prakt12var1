$(function(){
	$("#text").hide();
	$(".decor_t").hide();
	function runEffect(){
		$( "#text" ).effect( "drop", { direction: "right", mode: "show"}, 2000);
	};
	function runEffect2(){
		$( ".decor_t" ).effect( "drop", { direction: "left", mode: "show"}, 2000);
	};
	$("#imgf").click(function() {
    runEffect();
    });
	$("#imgd").click(function() {
    runEffect2();
    });			
});